---
name: Thank You
slug: thank-you
order: 30
pdf-page-style: single-column
---

# Thank You

Thanks for supporting and following these PDF releases. I am grateful to you. It is because of your support that I can continue creating cartography, and written content for RPG games. If you like what I do here, you might also be interested in some of my stuff that’s on sale at the DM’s Guild. These are paid products. Unfortunately I cannot distribute them to my supporters on Pat-reon because it would be copyright infringement.{.no-fancy}

I have two adventures, linked below, and a compilation of maps for the Forgotten Realms.

[<img src="images/sharn.jpg" alt="Sharn I, The Missing Schema" width=200>](https://www.dmsguild.com/product/249513/Sharn-The-Missing-Schema?affiliate_id=446018)
[<img src="images/sharn2.jpg" alt="Sharn II, Council of Roaches" width=200>](https://www.dmsguild.com/product/252138/Sharn-II-Council-of-Roaches?affiliate_rem=446018)
[<img src="images/mega-bundle.jpg" alt="Sword Coast Mega Bundle" width=200>](https://www.dmsguild.com/product/223992/Sword-Coast-Mega-Bundle?affiliate_id=446018)