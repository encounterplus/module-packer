---
name: Spells
slug: spells
pdf-page-style: multi-column
order: 9
---

# Spells

```Spell
name: Dumpster Fire
slug: dumpster-fire
level: 0
school: Evocation
ritual: false
time: 1 action
range: Self (30-foot radius)
components: V
duration: Concentration, up to 1 minute
description: "Ignites all nearby dumpsters."
classes: Sorcerer, Warlock, Wizard
image: DumpsterFire.jpg
source: Example Module
```