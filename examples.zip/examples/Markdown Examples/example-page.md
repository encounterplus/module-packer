---
name: Example Page
order: 1
---

![heading](heading.png){.size-cover}
# Heading 1

Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Massa tempor nec feugiat nisl pretium fusce id. Tincidunt augue interdum velit euismod. Odio pellentesque diam volutpat commodo sed egestas. Mattis molestie a iaculis at erat. Nibh venenatis cras sed felis. Dignissim enim sit amet venenatis urna cursus eget nunc scelerisque. 