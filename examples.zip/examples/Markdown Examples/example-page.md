---
name: Example Page
order: 1
---

![heading](heading.png){.size-cover}
# Heading 1

Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Massa tempor nec feugiat nisl pretium fusce id. Tincidunt augue interdum velit euismod. Odio pellentesque diam volutpat commodo sed egestas. Mattis molestie a iaculis at erat. Nibh venenatis cras sed felis. Dignissim enim sit amet venenatis urna cursus eget nunc scelerisque. 

## Link Styling

#### Standard Links

[Page](/page/myPage)

[Monster](/monster/myMonster)

[Item](/item/myItem)

[Spell](/spell/mySpell)

[Roll](/roll/1d20)

#### Styled Links

[Page](/page/myPage){.blue}

[Page](/page/myPage){.green}

[Page](/page/myPage){.red}

[Page](/page/myPage){.yellow}

[Page](/page/myPage){.neutral}

[Page](/page/myPage){.gray}

[Page](/page/myPage){.purple}

[Page](/page/myPage){.black}

[Page](/page/myPage){.black .underline}