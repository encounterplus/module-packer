---
name: Items
slug: items
pdf-page-style: multi-column
order: 9
---

# Items

```Item
name: Quarterstaff of Thwacking
slug: quarterstaff-of-thwacking
type: Melee Weapon
attunement: Requires attunement by a monk
primaryDamage: 1d6
secondaryDamage: 1d8
properties:
    - Versatile
    - Finesse
damageType: Bludgeoning
description: "This legendary quarterstaff has thwacked many a foe."
value: 1
source: Example Module
```

```Item  {.green}
name: +4 Shoe
slug: plus-four-shoe
type: Ammunition
rarity: Legendary
description: You have +4 bonus to attack and damage rolls made with this piece of ammunition. Once it hits a target, the ammunition is no longer magical.
value: 10000
weight: 0.05
source: Example Module
image: ShoePlusFour.jpg
```

```Item  {.red}
name: +4 Shoe
type: Ammunition
rarity: Legendary
description: You have +4 bonus to attack and damage rolls made with this piece of ammunition. Once it hits a target, the ammunition is no longer magical.
value: 10000
weight: 0.05
source: Example Module
image: ShoePlusFour.jpg
```

```Item  {.yellow}
name: +4 Shoe
type: Ammunition
rarity: Legendary
description: You have +4 bonus to attack and damage rolls made with this piece of ammunition. Once it hits a target, the ammunition is no longer magical.
value: 10000
weight: 0.05
source: Example Module
image: ShoePlusFour.jpg
```

```Item  {.orange}
name: +4 Shoe
type: Ammunition
rarity: Legendary
description: You have +4 bonus to attack and damage rolls made with this piece of ammunition. Once it hits a target, the ammunition is no longer magical.
value: 10000
weight: 0.05
source: Example Module
image: ShoePlusFour.jpg
```

```Item  {.purple}
name: +4 Shoe
type: Ammunition
rarity: Legendary
description: You have +4 bonus to attack and damage rolls made with this piece of ammunition. Once it hits a target, the ammunition is no longer magical.
value: 10000
weight: 0.05
source: Example Module
image: ShoePlusFour.jpg
```

